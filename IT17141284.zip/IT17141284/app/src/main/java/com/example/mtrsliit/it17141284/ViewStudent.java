package com.example.mtrsliit.it17141284;

public class ViewStudent {
}
